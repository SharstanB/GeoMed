﻿
$(document).on('click', '#newReviewButton', function () {
    $('#newReview').modal('show')
});

$('p').css({color: 'red'})